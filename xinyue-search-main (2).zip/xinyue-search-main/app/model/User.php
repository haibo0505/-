<?php

namespace app\model;

use app\model\QfShop;

class User extends QfShop
{
}
