<?php

namespace app\model;

use app\model\QfShop;

class App extends QfShop
{
}
