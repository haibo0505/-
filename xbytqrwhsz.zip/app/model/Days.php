<?php

namespace app\model;

use app\model\QfShop;

class Days extends QfShop
{
   
}
