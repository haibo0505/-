<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:56:"「推荐」白月梵星（2025）4K EDR 60FPS S01完结";s:3:"url";s:35:"https://pan.quark.cn/s/7b8d52e5363c";s:7:"is_type";i:0;s:3:"fid";s:32:"a8a342021ce24ae499f4d0c36c2cfef3";s:7:"is_time";i:1;s:11:"update_time";i:1737793797;s:11:"create_time";i:1737793797;s:2:"id";i:28;}i:1;a:8:{s:5:"title";s:66:"「推荐」龙珠大魔（2024）CR 1080p 内封简中 更至EP15";s:3:"url";s:35:"https://pan.quark.cn/s/955ecda74818";s:7:"is_type";i:0;s:3:"fid";s:32:"36ced9a6dc8041e785fa1d5fa89fbc1e";s:7:"is_time";i:1;s:11:"update_time";i:1737793812;s:11:"create_time";i:1737793812;s:2:"id";i:29;}}