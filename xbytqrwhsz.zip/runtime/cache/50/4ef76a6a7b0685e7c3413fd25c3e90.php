<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:23:"大奉打更人更至22";s:3:"url";s:35:"https://pan.quark.cn/s/6b2c57209216";s:7:"is_type";i:0;s:3:"fid";s:32:"08bdd75c8bf346c2bc680bcfef51b82d";s:7:"is_time";i:1;s:11:"update_time";i:1736251835;s:11:"create_time";i:1736251835;s:2:"id";i:77;}i:1;a:8:{s:5:"title";s:58:"「推荐」大奉打更人 (2024) 臻彩4K.更新至16集";s:3:"url";s:35:"https://pan.quark.cn/s/32b9c91dd3e9";s:7:"is_type";i:0;s:3:"fid";s:32:"9bbe695cbda64718942cebd0004ca3cf";s:7:"is_time";i:1;s:11:"update_time";i:1736251845;s:11:"create_time";i:1736251845;s:2:"id";i:82;}}