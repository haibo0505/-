<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:16:"小巷人家2024";s:3:"url";s:35:"https://pan.quark.cn/s/8bb9e80a4fed";s:7:"is_type";i:0;s:3:"fid";s:32:"652a0f22e86340c4b9e2790c9f4bff20";s:7:"is_time";i:1;s:11:"update_time";i:1736000729;s:11:"create_time";i:1736000729;s:2:"id";i:36;}i:1;a:8:{s:5:"title";s:58:"「推荐」小巷人家 4K高码率 [无台标][全40集]";s:3:"url";s:35:"https://pan.quark.cn/s/d5736dd2a134";s:7:"is_type";i:0;s:3:"fid";s:32:"beabdfa9f10e485b97c78f654499a6dc";s:7:"is_time";i:1;s:11:"update_time";i:1736000743;s:11:"create_time";i:1736000743;s:2:"id";i:40;}}