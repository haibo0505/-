<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:18:"再借幸福人生";s:3:"url";s:35:"https://pan.quark.cn/s/cb27d28b376f";s:7:"is_type";i:0;s:3:"fid";s:32:"24c5b28d5eac45abb0ed3fac1c710922";s:7:"is_time";i:1;s:11:"update_time";i:1736144266;s:11:"create_time";i:1736144266;s:2:"id";i:47;}i:1;a:8:{s:5:"title";s:41:"「推荐」再借幸福人生（34集）";s:3:"url";s:35:"https://pan.quark.cn/s/49489e9915da";s:7:"is_type";i:0;s:3:"fid";s:32:"02d47599cec749e0a1802e27080f2a38";s:7:"is_time";i:1;s:11:"update_time";i:1736144280;s:11:"create_time";i:1736144280;s:2:"id";i:49;}}