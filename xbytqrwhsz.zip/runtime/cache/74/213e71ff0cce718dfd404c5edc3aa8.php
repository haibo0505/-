<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:42:"好孕甜妻被钻石老公宠上天短剧";s:3:"url";s:35:"https://pan.quark.cn/s/4eef2b99eadd";s:7:"is_type";i:0;s:3:"fid";s:32:"b481269e27e34061aa0f8ce944a76dd7";s:7:"is_time";i:1;s:11:"update_time";i:1737688031;s:11:"create_time";i:1737688031;s:2:"id";i:6;}i:1;a:8:{s:5:"title";s:68:"「推荐」2025年1月16日 精选付费短剧43步更新 【41G】";s:3:"url";s:35:"https://pan.quark.cn/s/7d1b696be4b7";s:7:"is_type";i:0;s:3:"fid";s:32:"3914a4fe371143f3a962ad4a99c27999";s:7:"is_time";i:1;s:11:"update_time";i:1737688042;s:11:"create_time";i:1737688042;s:2:"id";i:7;}}