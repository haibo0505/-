<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:13:"猎罪图鉴2";s:3:"url";s:35:"https://pan.quark.cn/s/f749aa2b800d";s:7:"is_type";i:0;s:3:"fid";s:32:"e2bffe215bb54d8bb8594fd88e345e00";s:7:"is_time";i:1;s:11:"update_time";i:1736251852;s:11:"create_time";i:1736251852;s:2:"id";i:88;}i:1;a:8:{s:5:"title";s:75:"「推荐」猎罪图鉴2 4K高码率 [60帧率版][附第一季][全28集]";s:3:"url";s:35:"https://pan.quark.cn/s/ddca2916d824";s:7:"is_type";i:0;s:3:"fid";s:32:"ecfbe7b993e64659b06c43d6396dd098";s:7:"is_time";i:1;s:11:"update_time";i:1736251861;s:11:"create_time";i:1736251861;s:2:"id";i:90;}}