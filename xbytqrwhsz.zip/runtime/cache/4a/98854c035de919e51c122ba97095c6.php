<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:20:"真心英雄更至08";s:3:"url";s:35:"https://pan.quark.cn/s/8d2300242ddd";s:7:"is_type";i:0;s:3:"fid";s:32:"6ae2777e1004467f8f53529fac6783aa";s:7:"is_time";i:1;s:11:"update_time";i:1736144318;s:11:"create_time";i:1736144318;s:2:"id";i:50;}i:1;a:8:{s:5:"title";s:72:"「推荐」【国产剧】真心英雄 更至05集 国语中字 2025 4K";s:3:"url";s:35:"https://pan.quark.cn/s/5090032d860f";s:7:"is_type";i:0;s:3:"fid";s:32:"570bc08557264b09bf1add83af428c32";s:7:"is_time";i:1;s:11:"update_time";i:1736144330;s:11:"create_time";i:1736144330;s:2:"id";i:51;}}