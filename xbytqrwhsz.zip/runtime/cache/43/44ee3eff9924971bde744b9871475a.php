<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:20:"蔷薇风暴更至20";s:3:"url";s:35:"https://pan.quark.cn/s/6d665ac7307e";s:7:"is_type";i:0;s:3:"fid";s:32:"a48efa8efd0a41ddbec6252395edbe48";s:7:"is_time";i:1;s:11:"update_time";i:1736251838;s:11:"create_time";i:1736251838;s:2:"id";i:78;}i:1;a:8:{s:5:"title";s:53:"「推荐」【更新至 16 】蔷薇风暴 (2024) 4K";s:3:"url";s:35:"https://pan.quark.cn/s/017e38079805";s:7:"is_type";i:0;s:3:"fid";s:32:"744f83c1c9864b02bbf5d80c1ec71e22";s:7:"is_time";i:1;s:11:"update_time";i:1736251848;s:11:"create_time";i:1736251848;s:2:"id";i:85;}}