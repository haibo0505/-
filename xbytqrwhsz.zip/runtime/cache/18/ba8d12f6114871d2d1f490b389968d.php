<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:12:"凤君短剧";s:3:"url";s:35:"https://pan.quark.cn/s/0819d336b304";s:7:"is_type";i:0;s:3:"fid";s:32:"e601f304ebfe436d907e31f7df97b4e6";s:7:"is_time";i:1;s:11:"update_time";i:1738637822;s:11:"create_time";i:1738637822;s:2:"id";i:108;}i:1;a:8:{s:5:"title";s:94:"「推荐」2025年2月3日  精选付费短剧更新5部  春节短剧看不停 【47.2G】";s:3:"url";s:35:"https://pan.quark.cn/s/7e795c390211";s:7:"is_type";i:0;s:3:"fid";s:32:"172abaeb8d2b4f1d8ea43a61b9bfbfb6";s:7:"is_time";i:1;s:11:"update_time";i:1738637842;s:11:"create_time";i:1738637842;s:2:"id";i:109;}}