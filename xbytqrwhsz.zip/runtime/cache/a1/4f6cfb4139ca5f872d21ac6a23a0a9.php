<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:12:"蓝色监狱";s:3:"url";s:35:"https://pan.quark.cn/s/a3e31b529958";s:7:"is_type";i:0;s:3:"fid";s:32:"a951b3e4ebf742ce8f1b09ce24b8ef22";s:7:"is_time";i:1;s:11:"update_time";i:1736202369;s:11:"create_time";i:1736202369;s:2:"id";i:60;}i:1;a:8:{s:5:"title";s:86:"「推荐」【日漫】蓝色监狱 第二季 更新 14(38)完结【1080 高码率】";s:3:"url";s:35:"https://pan.quark.cn/s/8e9a5f40f716";s:7:"is_type";i:0;s:3:"fid";s:32:"a05c27a8c02b417cb81351b3ddcedb58";s:7:"is_time";i:1;s:11:"update_time";i:1736202379;s:11:"create_time";i:1736202379;s:2:"id";i:62;}}