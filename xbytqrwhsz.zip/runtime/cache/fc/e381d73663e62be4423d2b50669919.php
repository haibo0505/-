<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:12:"金牌销售";s:3:"url";s:35:"https://pan.quark.cn/s/f455d3e941fa";s:7:"is_type";i:0;s:3:"fid";s:32:"d3ad8a7f29c0473e8e9a02915c22590f";s:7:"is_time";i:1;s:11:"update_time";i:1738916930;s:11:"create_time";i:1738916930;s:2:"id";i:113;}i:1;a:8:{s:5:"title";s:48:"「推荐」2025年2月4日短剧热搜榜前十";s:3:"url";s:35:"https://pan.quark.cn/s/67c8c74387bf";s:7:"is_type";i:0;s:3:"fid";s:32:"78f9f9229b1140f5a259ce183e5baef8";s:7:"is_time";i:1;s:11:"update_time";i:1738916944;s:11:"create_time";i:1738916944;s:2:"id";i:115;}}