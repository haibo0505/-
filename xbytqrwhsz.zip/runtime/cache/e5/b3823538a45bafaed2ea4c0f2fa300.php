<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:16:"国色芳华2025";s:3:"url";s:35:"https://pan.quark.cn/s/cfab8d7bb7ab";s:7:"is_type";i:0;s:3:"fid";s:32:"aafad7af96214a939d69fa0bd8aed8a6";s:7:"is_time";i:1;s:11:"update_time";i:1737691738;s:11:"create_time";i:1737691738;s:2:"id";i:12;}i:1;a:8:{s:5:"title";s:102:"「推荐」国色芳华 (2025) 更新32   完结 1080p/4K  【杨紫/李现/爱情】附小说+彩蛋";s:3:"url";s:35:"https://pan.quark.cn/s/404161c99ee6";s:7:"is_type";i:0;s:3:"fid";s:32:"bbe00be036674bfdba387ee7307d1643";s:7:"is_time";i:1;s:11:"update_time";i:1737691749;s:11:"create_time";i:1737691749;s:2:"id";i:13;}}