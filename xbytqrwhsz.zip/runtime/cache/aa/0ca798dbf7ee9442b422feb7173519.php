<?php
//000000000060
 exit();?>
a:1:{i:0;a:8:{s:5:"title";s:12:"锦墨风华";s:3:"url";s:35:"https://pan.quark.cn/s/0738a691f91c";s:7:"is_type";i:0;s:3:"fid";s:32:"284d834cdc344c30bf45c11ff0a17c0b";s:7:"is_time";i:1;s:11:"update_time";i:1736251876;s:11:"create_time";i:1736251876;s:2:"id";i:93;}}