<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:27:"凡人修仙传虚天战纪";s:3:"url";s:35:"https://pan.quark.cn/s/1b6fc566bcbd";s:7:"is_type";i:0;s:3:"fid";s:32:"a741f4717832414aaf5e8bb2f8856f61";s:7:"is_time";i:1;s:11:"update_time";i:1737793209;s:11:"create_time";i:1737793209;s:2:"id";i:26;}i:1;a:8:{s:5:"title";s:84:"「推荐」凡人修仙传 ：外海风云 (2025)  更新126 4K  【热播国漫】";s:3:"url";s:35:"https://pan.quark.cn/s/fcb7f765cc8c";s:7:"is_type";i:0;s:3:"fid";s:32:"7e0d2e7d9baa4c8cbcb65b00020654a3";s:7:"is_time";i:1;s:11:"update_time";i:1737793219;s:11:"create_time";i:1737793219;s:2:"id";i:27;}}