<?php
//000000000060
 exit();?>
a:2:{i:0;a:8:{s:5:"title";s:37:"异人之下之决战！碧游村2025";s:3:"url";s:35:"https://pan.quark.cn/s/2c44cf54a021";s:7:"is_type";i:0;s:3:"fid";s:32:"01b22a5074464488aa3052e9c4b057a7";s:7:"is_time";i:1;s:11:"update_time";i:1737793082;s:11:"create_time";i:1737793082;s:2:"id";i:24;}i:1;a:8:{s:5:"title";s:95:"「推荐」异人之下之决战！碧游村 / 异人之下 (2025) 4K 60FPS 13集全 已完结";s:3:"url";s:35:"https://pan.quark.cn/s/3cf846cf12b0";s:7:"is_type";i:0;s:3:"fid";s:32:"c1b3baa9d1884cbaa0d031437625ee42";s:7:"is_time";i:1;s:11:"update_time";i:1737793093;s:11:"create_time";i:1737793093;s:2:"id";i:25;}}