<?php /*a:5:{s:53:"/www/wwwroot/x.0nb.cn/app/index/view/news/detail.html";i:1730771580;s:55:"/www/wwwroot/x.0nb.cn/app/index/view/common/header.html";i:1730771580;s:53:"/www/wwwroot/x.0nb.cn/app/index/view/common/head.html";i:1730771580;s:53:"/www/wwwroot/x.0nb.cn/app/index/view/common/foot.html";i:1730771580;s:55:"/www/wwwroot/x.0nb.cn/app/index/view/common/footer.html";i:1730771580;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php if(!(empty($config['app_icon']) || (($config['app_icon'] instanceof \think\Collection || $config['app_icon'] instanceof \think\Paginator ) && $config['app_icon']->isEmpty()))): ?>
    <link rel="icon" href="<?php echo htmlentities($config['app_icon']); ?>" />
    <?php endif; ?>
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width,user-scalable=no,maximum-scale=1.0">
    <title><?php echo htmlentities($seo_title); ?></title>
    <meta name="keywords" content="<?php echo htmlentities($seo_keywords); ?>" />
    <meta name="description" content="<?php echo htmlentities($seo_description); ?>" />
    <link rel="stylesheet" href="/static/index/css/index.min.css">
    <link rel="stylesheet" href="/static/index/css/app.css">
    <link rel="stylesheet" href="/static/index/css/m.css">
    
    <?php echo $config['seo_statistics']; ?>
    
    <style>
        :root {
            --theme-color: <?php echo htmlentities((isset($config['home_color']) && ($config['home_color'] !== '')?$config['home_color']:'#3e3e3e')); ?>;
            --theme-theme: <?php echo htmlentities((isset($config['home_theme']) && ($config['home_theme'] !== '')?$config['home_theme']:'#133ab3')); ?>;
            --theme-background: <?php echo htmlentities((isset($config['home_background']) && ($config['home_background'] !== '')?$config['home_background']:'#fafafa')); ?>;
            --theme-other_background: <?php echo htmlentities((isset($config['other_background']) && ($config['other_background'] !== '')?$config['other_background']:'#ffffff')); ?>;
        }
        <?php echo htmlentities($config['home_css']); ?>
    </style>
</head>
<body>
    <div class="headBg" style="background-image: url(<?php echo htmlentities($config['home_bg']); ?>);"></div>
    <div id="app" v-cloak>
        <div class="headerBox">
    <div class="bg" <?php if(!(empty($fixed) || (($fixed instanceof \think\Collection || $fixed instanceof \think\Paginator ) && $fixed->isEmpty()))): ?>:style="{ opacity: elementOpacity }"<?php endif; ?>></div>
    <div class="box">
        <a href="/" class="logoBox" <?php if(!(empty($fixed) || (($fixed instanceof \think\Collection || $fixed instanceof \think\Paginator ) && $fixed->isEmpty()))): ?>:style="{ opacity: elementOpacity }"<?php endif; ?>>
            <?php if(!(empty($config['logo']) || (($config['logo'] instanceof \think\Collection || $config['logo'] instanceof \think\Paginator ) && $config['logo']->isEmpty()))): ?>
            <img class="logo" src="<?php echo htmlentities($config['logo']); ?>"></img>
            <?php endif; if($config['app_name'] && $config['app_name_hide']!=1): ?>
            <div class="title"><?php echo htmlentities($config['app_name']); ?></div>
            <?php endif; ?>
        </a>
        <div class="search" <?php if(!(empty($fixed) || (($fixed instanceof \think\Collection || $fixed instanceof \think\Paginator ) && $fixed->isEmpty()))): ?>:style="{ opacity: elementOpacity }"<?php endif; ?>>
            <input type="text" v-model="keyword" placeholder="输入关键字进行搜索" @keyup.enter="searchBtn" confirm-type="search" @confirm="searchBtn">
            <div class="btn" @click="searchBtn">
                <i class="iconfont icon-sousuo"></i>
            </div>
        </div>
        <div class="navs">
            <?php if(!(empty($config['qcode']) || (($config['qcode'] instanceof \think\Collection || $config['qcode'] instanceof \think\Paginator ) && $config['qcode']->isEmpty()))): ?>
            <div class="item" @click="qcodeVisible = true">加入群聊</div>
            <?php endif; if(empty($config['app_demand']) || (($config['app_demand'] instanceof \think\Collection || $config['app_demand'] instanceof \think\Paginator ) && $config['app_demand']->isEmpty())): ?>
            <div class="item" @click="layerVisible = true">提交需求</div>
            <?php endif; ?>
            <div class="btns" v-html="`<?php echo htmlentities($config['app_links']); ?>`"></div>
            
            <div class="iconfont icon-caidan" @click="drawer = true"></div>
        </div>
    </div>
</div>
<div class="headerKox"></div>


<el-dialog
    v-model="qcodeVisible"
    width="300"
  >
    <img src="<?php echo htmlentities($config['qcode']); ?>" style="width: 100%" />
</el-dialog>

<el-dialog
    v-model="layerVisible"
    width="300"
  >
    <div class="layerBox">
		<div class="vname">提交需求</div>
	    <el-input
            v-model="content"
            placeholder="请输入你想看的资源信息~"
            type="textarea"
            resize='none'
          ></el-input>
		<div class="vbtn" @click="saveBtn">提交</div>
	</div>
</el-dialog>
<el-dialog
    v-model="drawer"
    width="300"
    center
  >
    <div class="drawer">
        <?php if(!(empty($config['qcode']) || (($config['qcode'] instanceof \think\Collection || $config['qcode'] instanceof \think\Paginator ) && $config['qcode']->isEmpty()))): ?>
        <div class="item" @click="qcodeVisible = true">加入群聊</div>
        <?php endif; if(empty($config['app_demand']) || (($config['app_demand'] instanceof \think\Collection || $config['app_demand'] instanceof \think\Paginator ) && $config['app_demand']->isEmpty())): ?>
        <div class="item" @click="layerVisible = true">提交需求</div>
        <?php endif; ?>
        <div class="btns" v-html="`<?php echo htmlentities($config['app_links']); ?>`"></div>
    </div>
</el-dialog>
        <div class="searchBox searchDetail">
            <div class="search">
                <input type="text" v-model="keyword" placeholder="输入关键字进行搜索" @keyup.enter="searchBtn" confirm-type="search" @confirm="searchBtn">
                <div class="btn" @click="searchBtn">
                    <i class="iconfont icon-sousuo"></i>
                </div>
            </div>
        </div>
        <div class="listBox detailBox">
            <div class="left">
                <h3>详情</h3>
                <div class="box details">
                    <?php if(!(empty($detail['vod_pic']) || (($detail['vod_pic'] instanceof \think\Collection || $detail['vod_pic'] instanceof \think\Paginator ) && $detail['vod_pic']->isEmpty()))): ?>
                    <div class="pic">
                        <img src="<?php echo htmlentities($detail['vod_pic']); ?>" />
                    </div>
                    <?php endif; ?>
                    <div class="title"><?php echo htmlentities($detail['title']); ?></div>
                    <div class="cat">
                        <div class="l">资源分类</div>
                        <div class="r">
                            <?php if($detail['category'] && $detail['category']['name']): ?>
                            <?php echo htmlentities($detail['category']['name']); else: ?>
                            其它
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="cat">
                        <div class="l">资源描述</div>
                        <div class="r">
                            <?php if($detail['vod_content']): ?>
                            <?php echo htmlentities($detail['vod_content']); else: ?>
                            -
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="cat">
                        <div class="l">更新时间</div>
                        <div class="r"><?php echo htmlentities($detail['times']); ?></div>
                    </div>
                    <div class="cat">
                        <div class="l">资源类型</div>
                        <div class="r">
                            <img src="/static/index/images/<?php echo htmlentities($detail['is_type']); ?>.png" class="icon" />
                            <?php if($detail['is_type']==1): ?>
                            <span>阿里云盘</span>
                            <?php elseif($detail['is_type']==2): ?>
                            <span>百度网盘</span>
                            <?php elseif($detail['is_type']==3): ?>
                            <span>UC网盘</span>
                            <?php elseif($detail['is_type']==4): ?>
                            <span>迅雷网盘</span>
                            <?php else: ?>
                            <span>夸克网盘</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="cat">
                        <div class="l">资源地址</div>
                        <div class="r">
                            <a href="<?php echo htmlentities($detail['url']); ?>" target="_blank"><?php echo htmlentities($detail['url']); ?></a>
                        </div>
                    </div>
                    <?php if(!(empty($detail['code']) || (($detail['code'] instanceof \think\Collection || $detail['code'] instanceof \think\Paginator ) && $detail['code']->isEmpty()))): ?>
                    <div class="cat">
                        <div class="l">提取码</div>
                        <div class="r" style="color: #FF3F3D;"><?php echo htmlentities($detail['code']); ?></div>
                    </div>
                    <?php endif; ?>
                    <div class="btns">
                        <div class="btn btnCol" @click.stop="copyText($event,'<?php echo htmlentities(trim($detail['title'])); ?>','<?php echo htmlentities($detail['url']); ?>','<?php echo htmlentities($detail['code']); ?>')"><i class="iconfont icon-fenxiang1"></i>复制分享</div>
                        <a  href="<?php echo htmlentities($detail['url']); ?>" target="_blank" class="btn"><i class="iconfont icon-yun_o"></i>立即访问</a>
                    </div>
                </div>
                <h3 class="samelistNav">相关资源</h3>
                <div class="box details samelistBox">
                    <div class="samelist">
                        <?php if(is_array($sameList) || $sameList instanceof \think\Collection || $sameList instanceof \think\Paginator): $i = 0; $__LIST__ = $sameList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <a href="/d/<?php echo htmlentities($vo['source_id']); ?>.html" class="item">
                            <p>
                                <span><?php echo htmlentities($key+1); ?></span>
                                <?php echo htmlentities($vo['title']); ?>
                            </p>
                        </a>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </div>
                </div>
            </div>
            <div class="right">
                <?php if(is_array($hotList) || $hotList instanceof \think\Collection || $hotList instanceof \think\Paginator): $i = 0; $__LIST__ = $hotList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="nav">
                        <?php if(!(empty($vo['image']) || (($vo['image'] instanceof \think\Collection || $vo['image'] instanceof \think\Paginator ) && $vo['image']->isEmpty()))): ?>
                        <img src="<?php echo htmlentities($vo['image']); ?>" :alt="<?php echo htmlentities($vo['name']); ?>">
                        <?php endif; ?>
                        <?php echo htmlentities($vo['name']); ?>
                    </div>
                    <div class="box">
                        <div class="list">
                            <?php if(is_array($vo['list']) || $vo['list'] instanceof \think\Collection || $vo['list'] instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($vo['list']) ? array_slice($vo['list'],0,5, true) : $vo['list']->slice(0,5, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vos): $mod = ($i % 2 );++$i;?>
                            <a href="/s/<?php echo htmlentities($vos['title']); ?>.html" class="item">
                                <p>
                                    <span><?php echo htmlentities($key+1); ?></span>
                                    <?php echo htmlentities($vos['title']); ?>
                                </p>
                            </a>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="footerBox">
    <div class="box">
        <p><?php echo $config['footer_dec']; ?></p>
        <p>
            <?php echo $config['footer_copyright']; ?>
            <a href="/sitemap.xml" target="_blank">网站地图</a>
        </p>
    </div>
</div>
    </div>
    <script src="/static/index/js/vue.global.min.js"></script>
<script src="/static/index/js/index.full.min.js"></script>
<script src="/static/index/js/axios.min.js"></script>
<script>
    const { createApp, ref, onMounted, onUnmounted } = Vue;
    const { ElButton, ElMessage  } = ElementPlus;
    const app = createApp({
        setup() {
            // 定义响应式数据
            const elementOpacity = ref(0);
            const scrollThreshold = ref(150); // 动态设置的滚动阈值
            const keyword = ref('<?php echo isset($keyword) ? htmlentities($keyword) : ''; ?>');
            const qcodeVisible = ref(false);
            const layerVisible = ref(false);
            const content = ref('');
            const load = ref(false)
            const drawer = ref(false)
            const rankList = ref([]);
            const rankDj = ref([]);
            const is_m = ref(0);
            const newList = ref([]);
            const QStatus = ref(0);
            const QList = ref([]);
            const QLoading = ref(false);
            const total_result = ref(0);
            
            
            // 公共消息方法
            const showMessage = (message, type = 'info') => {
                ElMessage({
                    message,
                    type,
                    plain: true,
                });
            };


             // 滚动监听方法
            const handleScroll = () => {
                const scrollTop = window.scrollY || document.documentElement.scrollTop;
                elementOpacity.value = scrollTop >= scrollThreshold.value
                    ? Math.min((scrollTop - scrollThreshold.value) / 100, 1)
                    : Math.max(1 - (scrollThreshold.value - scrollTop) / 100, 0);
    
                const boxElement = document.querySelector('.listBox .screen .fixed .box');
                if (boxElement.style.display === 'block' && is_m.value) {
                    boxElement.style.display = 'none'; // 隐藏元素
                }
            };

            // 搜索按钮点击事件
            const searchBtn = () => {
                if (!keyword.value) {
                    return showMessage('请输入你要搜索的内容~', 'error');
                }
                const currentUrl = window.location.href;
                const targetUrl = `/s/${keyword.value}.html`;
                if (currentUrl.includes('/s/') || currentUrl.includes('/d/')) {
                    window.location.href = targetUrl;
                } else {
                    window.open(targetUrl, '_blank');
                }
            };
            
            // 保存按钮点击事件
            const saveBtn = async () => {
                if (!content.value) {
                    return showMessage('请输入你想看的资源信息~', 'error');
                }
                if (load.value) return;
    
                load.value = true;
                try {
                    const response = await axios.post('/api/tool/feedback', { content: content.value });
                    showMessage(response.data.message, response.data.code === 200 ? 'success' : 'error');
                    if (response.data.code === 200) {
                        layerVisible.value = false;
                        content.value = '';
                    }
                } finally {
                    load.value = false;
                }
            };
            
            const setnum = (num) => (num / 10000).toFixed(2) + 'W';
            
            const goLink = (event,id) => {
                event.preventDefault();
                window.location.href = `/d/${id}.html`;
            }
            
            const changeBtn = (e) => {
                const category_id = `<?php echo htmlentities($category_id); ?>`;
                if(category_id){
                    window.location.href = `/s/${keyword.value}-${e}-${category_id}.html`;
                }else{
                    window.location.href = `/s/${keyword.value}-${e}.html`;
                }
            };
            
            const copyText = async(event,title,url,code) => {
                event.preventDefault();
                var text = '标题：'+title+'\n链接：'+url
                if (code) text += `\n提取码：${code}`;
                text += `\n由【${'<?php echo htmlentities($config['app_name']); ?>'}${window.location.hostname}】供网盘分享链接`;
                
                
                try {
                    // 优先使用 navigator.clipboard
                    await navigator.clipboard.writeText(text);
                    showMessage('复制成功', 'success');
                } catch (err) {
                    // 如果 navigator.clipboard 失败，使用 document.execCommand 作为回退
                    const textArea = document.createElement('textarea');
                    textArea.value = text;
                    textArea.style.position = 'fixed';  // 避免滚动
                    textArea.style.opacity = 0;
                    document.body.appendChild(textArea);
                    textArea.focus();
                    textArea.select();
            
                    try {
                        const successful = document.execCommand('copy');
                        if (successful) {
                            showMessage('复制成功', 'success');
                        } else {
                            throw new Error('复制失败');
                        }
                    } catch (err) {
                        showMessage('复制失败，请手动复制', 'error');
                    }
            
                    document.body.removeChild(textArea);
                }
            }
            
            const selectBtn = () => {
                const boxElement = document.querySelector('.listBox .screen .fixed .box');
                // 切换 display 属性，显示或隐藏
                if (boxElement.style.display === 'none' || boxElement.style.display === '') {
                    boxElement.style.display = 'block'; // 显示
                } else {
                    boxElement.style.display = 'none'; // 隐藏
                }
            }
            
            const handleDeviceType = () => {
                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                if (isMobile) {
                    // 手机端的逻辑
                    is_m.value = 1
                } else {
                    // 电脑端的逻辑
                    is_m.value = 0
                }
            };


            // 组件挂载时添加滚动监听
            onMounted(() => {
                handleDeviceType();
                
                window.addEventListener('scroll', handleScroll);
                window.addEventListener('resize', handleDeviceType);
            });

            // 组件卸载时移除滚动监听
            onUnmounted(() => {
                window.removeEventListener('scroll', handleScroll);
                window.removeEventListener('resize', handleDeviceType);
            });

            // 返回数据和方法
            return { elementOpacity, scrollThreshold, keyword, searchBtn, rankList,newList, setnum, qcodeVisible, layerVisible, content, saveBtn, rankDj,goLink,changeBtn,copyText,drawer,selectBtn,is_m,QList,QLoading,QStatus,total_result };
        }
    })
    .use(ElementPlus) // 使用 Element Plus
    .mount('#app'); // 挂载 Vue 实例
</script>
    <script type="text/javascript" charset="utf-8">
        app.rankList = JSON.parse('<?php echo json_encode($rankList, JSON_UNESCAPED_UNICODE); ?>');
        for (const item of app.rankList) {
            axios.get('/api/tool/ranking',{
                params: {
                  channel: item.name
                }
            })
        }
    </script>
</body>
</html>